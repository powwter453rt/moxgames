document.addEventListener("DOMContentLoaded", () => {
  fetch("jogos.json")
    .then(response => response.json())
    .then(jogos => {
      const catalogo = document.getElementById("catalogo");
      jogos.forEach(jogo => {
        const div = document.createElement("div");
        div.className = "jogo";
        div.innerHTML = `
          <img src="${jogo.capa}" alt="${jogo.nome}">
          <h3>${jogo.nome}</h3>
          <p>${jogo.genero}</p>
          <a class="botao" href="${jogo.link}">Ver Jogo</a>
        `;
        catalogo.appendChild(div);
      });
    });
});